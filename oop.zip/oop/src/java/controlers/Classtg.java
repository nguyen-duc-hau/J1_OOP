/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlers;

import java.util.Scanner;
import models.Coder;

/**
 *
 * @author ACER
 */
public class Classtg {

    /**
     *
     */
    public static void swc() {
        Scanner sc = new Scanner(System.in);

        int option = sc.nextInt(); // chon option

        switch (option) {
            case 1 ->
                System.out.println("java");
            case 2 ->
                System.out.println("python");
            case 3 ->
                System.out.println("C#");
            case 4 ->
                System.out.println("C++");

        }

    }

    public static void main(String[] args) {
        Coder coder = new Coder();

        Scanner sc = new Scanner(System.in);

        System.out.println("Nhap ten:");
        String name = sc.nextLine();
        coder.setName(name);

        // nhap tuoi tren 18
        System.out.println("Nhap tuoi:");
        int age = sc.nextInt();
        coder.setAge(age);
        while (coder.getAge() == 0) {
            age = sc.nextInt();
            coder.setAge(age);
        }

        System.out.println("Nhap SDT:");
        String phone = sc.next();
        coder.setPhone(phone);

        /*  System.out.println("Nhap ngon ngu:");
        String Language = sc.next();
        coder.setPrograming_Language(Language);
         */
        System.out.println("Ten:" + coder.getName());
        System.out.println("Tuoi:" + coder.getAge());
        System.out.println("SDT:" + coder.getPhone());
        //System.out.println("Ngon ngu:" + coder.getPrograming_Language());

        System.out.print("chon ngon ngu (1,2,3,4): ");

        swc();
    }
}
